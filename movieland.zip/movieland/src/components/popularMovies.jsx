import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../styles/popularMovies.css'; 
import { motion } from 'framer-motion';

const PopularMovies = () => {
  const [popularMovies, setPopularMovies] = useState([]);
  const [featuredMovies, setFeaturedMovies] = useState([]);
  const [currentSlide, setCurrentSlide] = useState(0);

  // Fetch movies
  useEffect(() => {
    const fetchMovies = async () => {
      const popularResponse = await axios.get(`https://api.themoviedb.org/3/movie/popular?api_key=57b15ecb00668d71aa90b06df16e76ad`);
      const featuredResponse = await axios.get(`https://api.themoviedb.org/3/movie/now_playing?api_key=57b15ecb00668d71aa90b06df16e76ad`);
      
      setPopularMovies(popularResponse.data.results);
      setFeaturedMovies(featuredResponse.data.results); // We'll use all the featured movies for sliding
    };
    fetchMovies();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prevSlide) => (prevSlide + 1) % Math.ceil(featuredMovies.length / 4)); // Slide by 4 movies each time
    }, 3000);
    return () => clearInterval(interval); 
  }, [featuredMovies]);

  const textVariants = {
    hidden: { opacity: 0, y: 30, rotate: -10 }, // Start off-screen, invisible, and slightly rotated
    visible: { opacity: 1, y: 0, rotate: 0 },   // Move to its position, become visible, and reset rotation
  };

  return (
    <div>
      {/* Slideshow Section */}
      <section className="slideshow">
        <h2>Top Trending Movies</h2>
        <motion.div 
          className="slideshow-container"
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          {featuredMovies.length > 0 && (
            <div className="slideshow-slide" style={{ transform: `translateX(${-currentSlide * 100}%)` }}>
              {featuredMovies.map((movie) => (
                <motion.div 
                  key={movie.id} 
                  className="slideshow-item"
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }} 
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <img src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`} alt={movie.title} />
                  <h3>{movie.title}</h3>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </section>

      {/* Text Content Section */}
      <motion.section 
        className="text-content"
        variants={textVariants}
        initial="hidden"
        animate="visible"
        exit="hidden"
        transition={{ duration: 1, type: "spring", stiffness: 80 }} // More dynamic spring effect
      >
        <motion.h2 
          initial={{ opacity: 0, scale: 0.8 }} 
          animate={{ opacity: 1, scale: 1 }} 
          transition={{ duration: 0.5 }}
        >
          Welcome to the Movie Zone!
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, x: -50 }} 
          animate={{ opacity: 1, x: 0 }} 
          transition={{ duration: 0.5, delay: 0.3 }} // Delay for staggered effect
        >
          Discover the latest and most popular movies, from thrilling action to heartwarming dramas. 
          Join us in exploring the world of cinema where stories come to life!
        </motion.p>
        
        {/* Additional animated text or effects for more engagement */}
        <motion.div 
          className="tagline"
          initial={{ opacity: 0, scale: 0.7 }} 
          animate={{ opacity: 1, scale: 1 }} 
          transition={{ duration: 0.5, delay: 0.6 }} // Delayed appearance for tagline
        >
          <p style={{ fontStyle: 'italic', fontSize: '1.2rem' }}>Your gateway to cinematic adventures!</p>
        </motion.div>
      </motion.section>

      {/* Popular Movies Section */}
      <section id="popular" className="popular-movies">
        <h2>Popular Movies</h2>
                    <div className="movie-grid">
            {popularMovies.map((movie) => (
                <motion.div 
                key={movie.id} 
                className="movie-card"
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                >
                <img src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`} alt={movie.title} />
                <h3>{movie.title}</h3>
                <p>Rating: {movie.vote_average}</p>
                </motion.div>
            ))}
            </div>

      </section>
    </div>
  );
};

export default PopularMovies;
