import React from 'react';
import PopularMovies from './popularMovies';
import FeaturedMovies from './featuredMovies';


const home = () => {
  return (
    <div className='Home'>
               <PopularMovies />  
               <FeaturedMovies/>
    </div>
  )
}

export default home
