import React from 'react';
import '../styles/header.css'; 

const Header = () => {
  return (
    <header className="header">
      <div className="logo">MovieLand</div>
      <nav>
        <ul className="nav-links">
          <li><a href="#hero">Home</a></li>
          <li><a href="#featured">Featured Movies</a></li>
          <li><a href="#popular">Popular Movies</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
