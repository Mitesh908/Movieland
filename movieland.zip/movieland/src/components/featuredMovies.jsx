import React, { useEffect, useState } from 'react';
import '../styles/featuredMovies.css'; 
import axios from 'axios';
import { motion } from 'framer-motion';

const FeaturedMovies = () => {
  const [movies, setMovies] = useState([]);

  
  useEffect(() => {
    const fetchFeaturedMovies = async () => {
      const response = await axios.get(`https://api.themoviedb.org/3/movie/now_playing?api_key=57b15ecb00668d71aa90b06df16e76ad`);
      setMovies(response.data.results);
    };
    fetchFeaturedMovies();
  }, []);

  return (
            <section id="featured" className="featured-movies">


            {/* Movie Grid */}
            <div className="movie-grid">
                {movies.map((movie) => (
                <div key={movie.id} className="movie-card">
                    <img src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`} alt={movie.title} />
                    <h3>{movie.title}</h3>
                    <p>Release Date: {movie.release_date}</p>
                </div>
                ))}
            </div>
            </section>
  );
};

export default FeaturedMovies;
