import React from 'react';
import Home from './components/home';  // Import the Home component
import Header from  './components/header';
import Footer from './components/footer';  // Import the Footer component
import './App.css';

function App() {
  return (
    <div className="App">
      <Header /> 
      <main>
        <Home />  
      </main>
      <Footer /> 
    </div>
  );
}

export default App;
